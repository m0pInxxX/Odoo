from odoo import models

class AccountMove(models.Model):
    _inherit = 'account.move'
