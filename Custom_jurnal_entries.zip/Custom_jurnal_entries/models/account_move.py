from odoo import models, fields

class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    description = fields.Char(string='Description')
    reference = fields.Char(string='Reference') 